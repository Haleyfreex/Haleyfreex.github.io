const User = require('../models/user');
const passport = require('passport');

const register = async (req, res) => {
    const { name, email, password } = req.body || {};
    if (!name || !email || !password) {
        return res.status(400).json({ message: 'Name, email, and password are required.' });
    }
    if (typeof password !== 'string' || password.length < 8) {
        return res.status(400).json({ message: 'Password must be at least 8 characters long.' });
    }
    if (!process.env.JWT_SECRET) {
        return res.status(500).json({ message: 'Authentication is not configured.' });
    }

    try {
        const user = new User({
            name: String(name).trim(),
            email: String(email).trim().toLowerCase()
        });
        user.setPassword(password);
        await user.save();

        return res.status(201).json({ token: user.generateJWT() });
    } catch (error) {
        if (error && error.code === 11000) {
            return res.status(409).json({ message: 'An account with that email already exists.' });
        }
        if (error && error.name === 'ValidationError') {
            return res.status(400).json({ message: 'Registration information is invalid.', details: error.message });
        }
        console.error('Registration error:', error);
        return res.status(500).json({ message: 'Unable to complete registration.' });
    }
};

const login = (req, res, next) => {
    const { email, password } = req.body || {};
    if (!email || !password) {
        return res.status(400).json({ message: 'Email and password are required.' });
    }
    if (!process.env.JWT_SECRET) {
        return res.status(500).json({ message: 'Authentication is not configured.' });
    }

    return passport.authenticate('local', (error, user, info) => {
        if (error) {
            return next(error);
        }
        if (!user) {
            return res.status(401).json({ message: (info && info.message) || 'Invalid email or password.' });
        }
        return res.status(200).json({ token: user.generateJWT() });
    })(req, res, next);
};

module.exports = { register, login };
