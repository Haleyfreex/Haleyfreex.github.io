const Trip = require('../models/travlr');

const tripFields = [
    'code', 'name', 'length', 'start',
    'resort', 'perPerson', 'image', 'description'
];

function tripPayload(body) {
    const payload = {};
    for (const field of tripFields) {
        if (Object.prototype.hasOwnProperty.call(body, field)) {
            payload[field] = body[field];
        }
    }
    return payload;
}

function handleDatabaseError(res, error) {
    if (error && error.code === 11000) {
        return res.status(409).json({ message: 'A trip with that code already exists.' });
    }
    if (error && (error.name === 'ValidationError' || error.name === 'CastError')) {
        return res.status(400).json({ message: 'Trip data is invalid.', details: error.message });
    }
    console.error('Trip API error:', error);
    return res.status(500).json({ message: 'An unexpected error occurred while processing the trip request.' });
}

const tripsList = async (req, res) => {
    try {
        const trips = await Trip.find({}).sort({ name: 1 }).exec();
        return res.status(200).json(trips);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
        if (!trip) {
            return res.status(404).json({ message: 'Trip not found.' });
        }
        return res.status(200).json(trip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

const tripsAddTrip = async (req, res) => {
    try {
        const newTrip = new Trip(tripPayload(req.body || {}));
        const savedTrip = await newTrip.save();
        return res.status(201).json(savedTrip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

const tripsUpdateTrip = async (req, res) => {
    try {
        const updates = tripPayload(req.body || {});
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ message: 'At least one trip field must be provided.' });
        }

        const updatedTrip = await Trip.findOneAndUpdate(
            { code: req.params.tripCode },
            { $set: updates },
            { new: true, runValidators: true, context: 'query' }
        ).exec();

        if (!updatedTrip) {
            return res.status(404).json({ message: 'Trip not found.' });
        }
        return res.status(200).json(updatedTrip);
    } catch (error) {
        return handleDatabaseError(res, error);
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};
