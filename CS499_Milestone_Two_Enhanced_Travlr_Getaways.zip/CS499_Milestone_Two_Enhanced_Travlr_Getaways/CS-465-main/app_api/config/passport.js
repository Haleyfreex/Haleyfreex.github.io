const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const User = require('../models/user');

passport.use(new LocalStrategy(
    { usernameField: 'email' },
    async (email, password, done) => {
        try {
            const user = await User.findOne({
                email: String(email).trim().toLowerCase()
            }).select('+hash +salt').exec();

            // Use one generic message so the endpoint does not disclose
            // whether a particular email address has an account.
            if (!user || !user.validPassword(password)) {
                return done(null, false, { message: 'Invalid email or password.' });
            }
            return done(null, user);
        } catch (error) {
            return done(error);
        }
    }
));
