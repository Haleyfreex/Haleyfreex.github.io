const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

// Retain the iteration count used by the original artifact so existing accounts remain valid.
const PASSWORD_ITERATIONS = 1000;
const PASSWORD_KEY_LENGTH = 64;
const PASSWORD_DIGEST = 'sha512';

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: true,
        lowercase: true,
        trim: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    hash: { type: String, required: true, select: false },
    salt: { type: String, required: true, select: false }
});

userSchema.methods.setPassword = function(password) {
    this.salt = crypto.randomBytes(16).toString('hex');
    this.hash = crypto.pbkdf2Sync(
        password,
        this.salt,
        PASSWORD_ITERATIONS,
        PASSWORD_KEY_LENGTH,
        PASSWORD_DIGEST
    ).toString('hex');
};

userSchema.methods.validPassword = function(password) {
    if (!this.salt || !this.hash || typeof password !== 'string') {
        return false;
    }

    const candidateHash = crypto.pbkdf2Sync(
        password,
        this.salt,
        PASSWORD_ITERATIONS,
        PASSWORD_KEY_LENGTH,
        PASSWORD_DIGEST
    );
    const storedHash = Buffer.from(this.hash, 'hex');

    return storedHash.length === candidateHash.length &&
        crypto.timingSafeEqual(storedHash, candidateHash);
};

userSchema.methods.generateJWT = function() {
    if (!process.env.JWT_SECRET) {
        throw new Error('JWT_SECRET is not configured.');
    }

    return jwt.sign(
        { _id: this._id, email: this.email, name: this.name },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
    );
};

const User = mongoose.model('users', userSchema);
module.exports = User;
