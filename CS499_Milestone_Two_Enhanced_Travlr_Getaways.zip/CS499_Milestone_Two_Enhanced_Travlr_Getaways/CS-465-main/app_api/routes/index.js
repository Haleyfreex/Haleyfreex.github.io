const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Protect administrative API operations with a valid Bearer token.
function authenticateJWT(req, res, next) {
    const authHeader = req.get('authorization');

    if (!authHeader) {
        return res.status(401).json({ message: 'Authorization token required.' });
    }

    const parts = authHeader.trim().split(/\s+/);
    if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer' || !parts[1]) {
        return res.status(401).json({ message: 'Authorization header must use the Bearer scheme.' });
    }

    if (!process.env.JWT_SECRET) {
        return res.status(500).json({ message: 'Authentication is not configured.' });
    }

    try {
        req.auth = jwt.verify(parts[1], process.env.JWT_SECRET);
        return next();
    } catch (error) {
        return res.status(401).json({ message: 'Invalid or expired authentication token.' });
    }
}

router.post('/register', authController.register);
router.post('/login', authController.login);

router.route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

router.route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip);

module.exports = router;
