import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule }
from '@angular/forms';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})

export class EditTrip implements OnInit {
  public editForm!: FormGroup;
  trip!: Trip;
  submitted = false;
  message : string ='';

  get f() {
    return this.editForm.controls;
  }

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripData: TripData
  ) {}

  ngOnInit(): void {

    // Retrieve stashed trip ID
    let tripCode = localStorage.getItem("tripCode");
    if (!tripCode) {
      alert("Something wrong, couldn't find where I stashed tripCode!");
      this.router.navigate(['']);
      return;
    }

    console.log('EditTrip::ngOnInit');
    console.log('tripcode:' + tripCode);

    // Initialize the edit form
    this.editForm = this.formBuilder.group({
      _id: [],
      code: [tripCode, Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
  })

  this.tripData.getTrip(tripCode)
    .subscribe({
      next: (value: Trip) => {
console.log('EDIT TRIP API VALUE');

        this.trip = value;

        // Populate our record into the form
        this.editForm.patchValue({
          ...value,
          start: value.start
            ? new Date(value.start as unknown as string).toISOString().split('T')[0]
            : ''
        });

        if(!value)
        {
          this.message = 'No Trip Received!';
        }
        else {
          this.message = 'Trip: ' + tripCode + ' retrieved';
        }
        console.log(this.message);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      }
    })
}

public onSubmit()
 {
  this.submitted = true;

  if(this.editForm.valid)
  {
    this.tripData.updateTrip(this.editForm.value)
     .subscribe({
      next: (value: any) => {
        console.log(value);
        this.router.navigate(['']);
      },
      error: (error: any) => {
        console.log('Error: ' + error);
      }
     })
  }
 }
}
