import { Inject, Injectable } from '@angular/core';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { TripData } from './trip-data';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripData
  ) {}

  authResp: AuthResponse = new AuthResponse();

  public getToken(): string {
    return this.storage.getItem('travlr-token') || '';
  }

  public saveToken(token: string): void {
    if (token) {
      this.storage.setItem('travlr-token', token);
    }
  }

  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  // Decode defensively: malformed or expired tokens must not break the UI.
  private getTokenPayload(): any | null {
    const token = this.getToken();
    if (!token) {
      return null;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      if (!payload.exp || payload.exp <= Date.now() / 1000) {
        this.logout();
        return null;
      }
      return payload;
    } catch {
      this.logout();
      return null;
    }
  }

  public isLoggedIn(): boolean {
    return this.getTokenPayload() !== null;
  }

  public getCurrentUser(): User | null {
    const payload = this.getTokenPayload();
    if (!payload || !payload.email || !payload.name) {
      return null;
    }
    return { email: payload.email, name: payload.name } as User;
  }

  public login(user: User, passwd: string): Observable<AuthResponse> {
    return this.tripDataService.login(user, passwd);
  }

  public register(user: User, passwd: string): Observable<AuthResponse> {
    return this.tripDataService.register(user, passwd);
  }
}
