import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})

export class Login implements OnInit {

  public formError: string = '';
  submitted = false;

  credentials = {
    name: '',
    email: '',
    password: ''
  }

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {
  }

  public onLoginSubmit(): void {
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password ||
          !this.credentials.name) {
      this.formError = 'All fields are required, please try again';
      this.router.navigateByUrl('#'); // Return to login page
    } else {
      this.doLogin();
    }
  }

private doLogin(): void {
  const newUser = {
    name: this.credentials.name,
    email: this.credentials.email
  } as User;

  this.authenticationService.login(newUser, this.credentials.password)
    .subscribe({
      next: (value) => {
        if (value && value.token) {
          this.authenticationService.saveToken(value.token);
          this.router.navigate(['']);
        } else {
          this.formError = 'Login failed. No token was returned.';
        }
      },
      error: (error) => {
        console.error('Login failed:', error);
        this.formError = 'Login failed. Please check your credentials.';
      }
    });
  }
}