# CS 499 Milestone Two - Software Design and Engineering Enhancement

## Artifact
Travlr Getaways (CS 465), a MEAN-stack travel application.

## Enhancement scope
This enhancement follows the CS 499 code-review plan focused on JWT verification, API error handling, and Angular authentication behavior.

## Changes made
- Reworked JWT middleware to require a correctly formatted Bearer token, verify it before continuing, reject invalid/expired tokens, and handle missing JWT configuration.
- Improved trip API controllers with try/catch handling, consistent JSON errors, correct not-found responses, duplicate-key handling, and validated updates that return the updated document.
- Improved registration and login validation and response consistency; duplicate email registration now returns HTTP 409.
- Hardened password comparison with Node's timing-safe comparison while retaining the original project's PBKDF2 iteration count for compatibility with existing user records.
- Loaded `.env` configuration before initializing the database connection.
- Made Angular token parsing defensive and clear malformed/expired tokens.
- Corrected the Angular HTTP interceptor method name and ensured authorization headers are attached only to non-authentication requests.

## Verification completed
- Ran `node --check` against the modified JavaScript files. All checked files passed syntax validation.

## Manual Integration Testing Completed

The application was tested locally using PowerShell, the Angular administrative interface, and a connected MongoDB database.

The following tests were completed:

1. Confirmed that public trip retrieval returned the existing trip records.
2. Confirmed that requesting a nonexistent trip returned HTTP 404.
3. Tested protected trip creation without a JWT and with an invalid JWT. Both requests were rejected.
4. Registered a test account and confirmed that duplicate email registration was rejected.
5. Tested login with valid credentials and confirmed that an incorrect password was rejected.
6. Submitted an incomplete trip request with a valid JWT and confirmed that authentication succeeded before trip validation returned HTTP 400.
7. Logged in through the Angular application and successfully created a temporary trip.
8. Edited the temporary trip through the Angular interface and confirmed that the updated name was saved.
9. Removed the temporary test record directly from MongoDB and verified that the four original trip records remained.

JavaScript syntax checks were also completed successfully using `node --check` on the modified JavaScript files.

## Additional Testing Considerations

Additional testing could further strengthen the application, particularly testing expired JWTs, malformed update requests, and all possible invalid input conditions. Dependency vulnerabilities reported during installation should also be reviewed before production deployment.