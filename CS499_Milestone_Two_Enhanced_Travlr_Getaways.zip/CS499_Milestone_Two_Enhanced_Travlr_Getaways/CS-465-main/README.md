# CS 465 Module Eight Journal: Travlr Getaways

## Project Overview

Travlr Getaways is a full stack web application designed to help customers explore travel packages while allowing administrators to manage trip information through a separate administrative interface. The project uses the MEAN stack, which consists of MongoDB, Express.js, Angular, and Node.js. Throughout this course, I developed both the customer-facing website and the administrative application, connected the frontend to backend API endpoints, and implemented authentication features to improve application security.

## Architecture

### Frontend Development

During this project, I worked with several types of frontend development, including Express HTML, JavaScript, and an Angular single-page application (SPA). Express HTML and Handlebars templates were used to generate dynamic web pages on the server. This approach allowed the application to display information retrieved from the backend and reuse common page elements, such as headers and navigation.

JavaScript added functionality to the application by allowing data to be processed and interactive behaviors to be implemented. The Angular SPA provided a different approach by allowing the administrative application to update its content dynamically without reloading the entire page for every interaction. Angular components, services, and routing helped organize the frontend and communicate with the backend API.

Each approach has its own advantages. Server-side rendering with Express and Handlebars is useful for generating complete HTML pages, while an Angular SPA provides a more interactive experience and separates the user interface from the backend. Using these approaches together helped me understand how different frontend technologies can support different needs within the same full stack application.

### Why MongoDB Was Used

The backend uses MongoDB because it is a NoSQL document database that stores information in flexible, JSON-like documents. This works well with a JavaScript-based application because data can move between the database, Node.js backend, and frontend with relatively little conversion.

MongoDB also allows records to have flexible structures, which can be useful when managing travel packages with different descriptions, prices, destinations, and other details. Mongoose helped the application interact with MongoDB by providing models and methods for retrieving, creating, updating, and deleting trip records. This made MongoDB a practical choice for the Travlr Getaways application.

## Functionality

### JSON and JavaScript

JavaScript and JSON are related, but they serve different purposes. JavaScript is a programming language used to implement application logic, handle events, process data, and create interactive features. JSON, which stands for JavaScript Object Notation, is a text-based data format used to represent and exchange structured information.

JSON connects the frontend and backend by providing a consistent format for transferring data through API requests and responses. For example, the Angular application can send a request to retrieve available trips from the Express API. The backend queries MongoDB, converts the results into JSON, and returns the data to Angular. The frontend can then use that information to display the available trips to the user.

In this project, the trips API endpoint at `/api/trips` was an important part of that communication. Angular services used HTTP requests to retrieve trip data, while the backend handled the database operations. This helped me understand how the frontend, backend, and database work together as parts of one application.

### Code Refactoring and Reusable UI Components

Throughout the project, I refactored code to improve functionality, organization, and maintainability. One example was organizing the Angular frontend into reusable components, including the trip listing and trip card components. Separating these responsibilities made the code easier to understand and allowed individual components to focus on specific tasks.

I also developed and refined services to handle communication with the backend. The trip data service was used for operations such as retrieving trips, retrieving an individual trip, adding a trip, and updating trip information. Centralizing these operations reduced duplicated code and made it easier to maintain communication with the API.

Another important improvement was implementing authentication for the administrative application. I worked with an authentication service to manage login information and authentication tokens, along with a JWT interceptor to attach the token to appropriate HTTP requests. This helped connect the security features with the rest of the application.

Reusable UI components provide several benefits. They reduce duplicated code, improve consistency across pages, simplify testing, and make future changes easier. When a component needs to be updated, the change can be made in one location rather than repeated throughout the application. These practices helped me better understand the importance of modular and maintainable software design.

## Testing

Testing a full stack application requires checking that each part of the system works correctly and communicates with the other parts. API testing is especially important because the frontend depends on backend endpoints to retrieve and modify information.

HTTP methods determine the type of operation being requested. For example, GET requests retrieve information, POST requests create resources or submit data, PUT requests update existing resources, and DELETE requests remove resources. Each method must be handled appropriately by the backend.

Endpoints identify the resources or operations that the API makes available. In Travlr Getaways, the `/api/trips` endpoint allows the application to communicate with the backend to retrieve trip information. Testing API endpoints involves checking successful responses, returned data, error handling, and whether database changes occur as expected.

Adding authentication introduces additional testing requirements. The application must verify that login credentials are valid, authentication tokens are handled correctly, and protected operations cannot be accessed by unauthorized users. Testing should include requests with valid tokens, invalid or expired tokens, and no token at all. It is also important to verify that public endpoints remain accessible where appropriate while administrative operations require authorization.

During development, I encountered issues involving backend connectivity, API requests, and authentication configuration. Troubleshooting these problems helped me understand that an error in one layer can affect the entire application. For example, if the backend server or database connection is unavailable, the Angular frontend may be unable to retrieve trip information. These experiences reinforced the importance of testing the frontend, backend, database connection, and security features together rather than assuming that each part works simply because it runs independently.

## Reflection

This course helped me develop a better understanding of how full stack web applications are designed, developed, and maintained. Before completing this project, I had experience with programming concepts, but building Travlr Getaways required me to connect multiple technologies and understand how they work together in a complete application.

I developed practical experience with MongoDB, Express.js, Angular, Node.js, REST APIs, JSON, and authentication using JSON Web Tokens. I also improved my ability to organize code into components and services, troubleshoot errors, work with database connections, and use Git and GitHub for version control. Working through problems with API connectivity, Angular forms, routing, and authentication taught me the importance of carefully reading error messages and testing changes systematically.

One of the most valuable lessons was learning that developing an application involves more than making the interface look correct. A successful application must also retrieve and update data reliably, protect restricted functionality, handle errors appropriately, and remain maintainable as the project grows.

These skills support my professional goals in computer science and software development. Experience with a MEAN stack application gives me a foundation for understanding modern web development workflows and collaborating on projects that involve both frontend and backend technologies. Completing this project also helped me become more comfortable solving unfamiliar technical problems and connecting concepts learned in class to practical programming tasks.

Overall, CS 465 gave me valuable hands-on experience that I can showcase in my GitHub portfolio. Travlr Getaways demonstrates my ability to work with a full stack architecture, build interactive user interfaces, integrate a database, implement authentication, and troubleshoot software issues. I plan to continue building on these skills as I pursue opportunities in the technology field.
